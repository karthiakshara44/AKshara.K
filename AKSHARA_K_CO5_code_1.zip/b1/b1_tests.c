#include <stdio.h>
typedef unsigned long long u64;
u64 calls = 0;

int digit_sum(long long n){ int s=0; while(n>0){ s+=n%10; n/=10;} return s; }
/* recursive digital root */
int digital_root(long long n){ if (n < 10) return (int)n; return digital_root(digit_sum(n)); }
/* loop version and closed formula */
int dr_loop(long long n){ while(n>=10) n=digit_sum(n); return (int)n; }
int dr_formula(long long n){ return n==0 ? 0 : (int)(1 + (n-1)%9); }

u64 power_linear(u64 b,int e){ calls++; if(e==0) return 1; return b*power_linear(b,e-1); }
u64 power_fast(u64 b,int e){ calls++; if(e==0) return 1; u64 h=power_fast(b,e/2); return (e%2)? h*h*b : h*h; }
u64 power_twice(u64 b,int e){ calls++; if(e==0) return 1; u64 r=power_twice(b,e/2)*power_twice(b,e/2); return (e%2)? r*b : r; }
u64 power_iter(u64 b,int e){ u64 r=1; while(e>0){ if(e&1) r*=b; b*=b; e>>=1;} return r; }

int main(void){
  long long dr_in[] = {0,1,9,10,493193,9875,999999999999LL};
  printf("digital root tests (recursive | loop | formula)\n");
  for(int i=0;i<7;i++) printf("  %lld -> %d | %d | %d\n",dr_in[i],digital_root(dr_in[i]),dr_loop(dr_in[i]),dr_formula(dr_in[i]));
  struct {u64 b; int e;} t[] = {{2,0},{2,1},{2,10},{3,13},{0,0},{0,5},{1,1000},{7,20},{5,25}};
  printf("power tests (linear | fast | twice | iterative)\n");
  for(int i=0;i<9;i++){
    calls=0; u64 a=power_linear(t[i].b,t[i].e);
    calls=0; u64 b=power_fast(t[i].b,t[i].e);
    calls=0; u64 c=power_twice(t[i].b,t[i].e);
    u64 d=power_iter(t[i].b,t[i].e);
    printf("  %llu^%d = %llu | %llu | %llu | %llu  %s\n",t[i].b,t[i].e,a,b,c,d,(a==b&&b==c&&c==d)?"OK":"MISMATCH");
  }
  printf("call counts (base 1)\n  n, linear, fast, twice\n");
  int ns[]={10,100,1000,10000};
  for(int i=0;i<4;i++){
    u64 l,f,w;
    calls=0; power_linear(1,ns[i]); l=calls;
    calls=0; power_fast(1,ns[i]); f=calls;
    calls=0; power_twice(1,ns[i]); w=calls;
    printf("  %d, %llu, %llu, %llu\n",ns[i],l,f,w);
  }
  return 0;
}
