#include <stdio.h>
#include <stdlib.h>
typedef unsigned long long u64;
u64 power_linear(u64 b,long e){ if(e==0) return 1; return b*power_linear(b,e-1); }
u64 power_iter(u64 b,long e){ u64 r=1; for(long i=0;i<e;i++) r*=b; return r; }
int main(int argc,char**argv){
  long n = atol(argv[1]); int iter = argc>2;
  u64 r = iter ? power_iter(1,n) : power_linear(1,n);
  printf("ok n=%ld result=%llu\n", n, r);
  return 0;
}
