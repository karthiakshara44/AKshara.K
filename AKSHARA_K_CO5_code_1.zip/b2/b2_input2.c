#include <stdio.h>
#include <string.h>
int main(void){ char name[16], next[16];
  fgets(name,sizeof name,stdin); fgets(next,sizeof next,stdin);
  name[strcspn(name,"\n")]=0; next[strcspn(next,"\n")]=0;
  printf("1st read: \"%s\"\n2nd read: \"%s\"\n", name, next); return 0; }
