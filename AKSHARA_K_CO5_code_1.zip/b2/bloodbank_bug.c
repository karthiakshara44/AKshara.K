/* District Blood Bank - command line program (CO5 Assignment 5)
   bloodbank init | stock | find <group> | issue <group> <units> | register
   Data: donors.txt (text, one donor per line), stock.dat (binary Stock records) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define NGROUPS 8
#define MIN_GAP_DAYS 90
static const char *GROUPS[NGROUPS] = {"A+","A-","B+","B-","AB+","AB-","O+","O-"};

typedef struct { int id; char name[32]; char group[4]; int age; char phone[16]; int last; } Donor; /* last = YYYYMMDD */
typedef struct { int group_code; int units; } Stock;
typedef struct { Donor *data; int size, capacity; } DonorList;
typedef struct { int count; int youngest_id; } EligibleInfo;

static const char *dir = ".";
static char path[256];
static const char *file_path(const char *f){ snprintf(path,sizeof path,"%s/%s",dir,f); return path; }

int group_index(const char *g){ for(int i=0;i<NGROUPS;i++) if(strcmp(g,GROUPS[i])==0) return i; return -1; }

long days_from_ymd(int ymd){ int y=ymd/10000,m=ymd/100%100,d=ymd%100;
  y -= m<=2; long era=(y>=0?y:y-399)/400; long yoe=y-era*400;
  long doy=(153*(m+(m>2?-3:9))+2)/5+d-1; long doe=yoe*365+yoe/4-yoe/100+doy; return era*146097+doe-719468; }
int today_ymd(void){ time_t t=time(NULL); struct tm *tm=localtime(&t); return (tm->tm_year+1900)*10000+(tm->tm_mon+1)*100+tm->tm_mday; }

int is_eligible(const Donor *d, int today){ return d->age>=18 && d->age<=65 && days_from_ymd(today)-days_from_ymd(d->last) >= MIN_GAP_DAYS; }

int add_donor(DonorList *l, const Donor *d){
  if(l->size==l->capacity){ int nc = l->capacity==0?2:l->capacity*2;
    Donor *p = realloc(l->data, (size_t)(nc-1)*sizeof *p);
    if(p==NULL) return 0;             /* old block still valid */
    l->data=p; l->capacity=nc; }
  l->data[l->size++]=*d; return 1; }

int load_donors(DonorList *l){
  FILE *fp=fopen(file_path("donors.txt"),"r");
  if(!fp){ perror(path); return 0; }
  char line[256]; Donor d;
  while(fgets(line,sizeof line,fp)){
    if(sscanf(line,"%d|%31[^|]|%3[^|]|%d|%15[^|]|%d",&d.id,d.name,d.group,&d.age,d.phone,&d.last)==6)
      if(!add_donor(l,&d)){ fprintf(stderr,"out of memory\n"); fclose(fp); return 0; } }
  fclose(fp); return 1; }

/* two outputs through a struct: count + youngest eligible id */
EligibleInfo summarise(const DonorList *l, const char *g, int today){
  EligibleInfo r={0,-1}; int ya=1000;
  for(int i=0;i<l->size;i++){ const Donor *d=&l->data[i];
    if(strcmp(d->group,g)==0 && is_eligible(d,today)){ r.count++; if(d->age<ya){ya=d->age; r.youngest_id=d->id;} } }
  return r; }

Stock *lowest_stock(Stock *s, int n){ Stock *m=&s[0]; for(int i=1;i<n;i++) if(s[i].units<m->units) m=&s[i]; return m; }

int update_units(FILE *fp,int index,int units){ Stock s;
  if(fseek(fp,(long)index*(long)sizeof s,SEEK_SET)!=0) return 0;
  if(fread(&s,sizeof s,1,fp)!=1) return 0;
  s.units=units;
  if(fseek(fp,-(long)sizeof s,SEEK_CUR)!=0) return 0;
  if(fwrite(&s,sizeof s,1,fp)!=1) return 0;
  return fflush(fp)==0; }

static int usage(void){ fprintf(stderr,"usage: bloodbank init | stock | find <group> | issue <group> <units> | register\n"
  "groups: A+ A- B+ B- AB+ AB- O+ O-\n"); return 2; }

int main(int argc,char **argv){
  if(getenv("BB_DIR")) dir=getenv("BB_DIR");
  if(argc<2) return usage();
  const char *cmd=argv[1];

  if(strcmp(cmd,"init")==0){ if(argc!=2) return usage();
    FILE *fp=fopen(file_path("stock.dat"),"wb"); if(!fp){ perror(path); return 1; }
    Stock s[NGROUPS]; for(int i=0;i<NGROUPS;i++){ s[i].group_code=i; s[i].units=10+7*i%23; }
    if(fwrite(s,sizeof(Stock),NGROUPS,fp)!=NGROUPS){ perror("fwrite"); fclose(fp); return 1; }
    fclose(fp); printf("stock.dat created\n"); return 0; }

  if(strcmp(cmd,"stock")==0){ if(argc!=2) return usage();
    FILE *fp=fopen(file_path("stock.dat"),"rb"); if(!fp){ perror(path); return 1; }
    Stock s[NGROUPS]; size_t n=fread(s,sizeof(Stock),NGROUPS,fp); fclose(fp);
    for(size_t i=0;i<n;i++) printf("%-3s %d\n",GROUPS[s[i].group_code],s[i].units);
    Stock *low=lowest_stock(s,(int)n); printf("lowest: %s (%d units)\n",GROUPS[low->group_code],low->units); return 0; }

  if(strcmp(cmd,"find")==0){ if(argc!=3) return usage();
    if(group_index(argv[2])<0){ fprintf(stderr,"invalid blood group '%s'\n",argv[2]); return 2; }
    DonorList l={NULL,0,0};
    if(!load_donors(&l)){ free(l.data); return 1; }
    int today=today_ymd(); EligibleInfo r=summarise(&l,argv[2],today);
    printf("eligible %s donors: %d, youngest id: %d\n",argv[2],r.count,r.youngest_id);
    return 0; }

  if(strcmp(cmd,"issue")==0){ if(argc!=4) return usage();
    int gi=group_index(argv[2]); if(gi<0){ fprintf(stderr,"invalid blood group '%s'\n",argv[2]); return 2; }
    char *end; long u=strtol(argv[3],&end,10);
    if(*end!='\0'||u<=0||u>1000){ fprintf(stderr,"invalid unit count '%s'\n",argv[3]); return 2; }
    FILE *fp=fopen(file_path("stock.dat"),"r+b"); if(!fp){ perror(path); return 1; }
    Stock s; fseek(fp,(long)gi*(long)sizeof s,SEEK_SET);
    if(fread(&s,sizeof s,1,fp)!=1){ fprintf(stderr,"stock record missing\n"); fclose(fp); return 1; }
    if(s.units<u){ fprintf(stderr,"only %d units of %s available\n",s.units,argv[2]); fclose(fp); return 1; }
    if(!update_units(fp,gi,s.units-(int)u)){ perror("update"); fclose(fp); return 1; }
    printf("issued %ld units of %s, %d left\n",u,argv[2],s.units-(int)u); fclose(fp); return 0; }

  if(strcmp(cmd,"register")==0){ if(argc!=2) return usage();
    char line[40]; Donor d; memset(&d,0,sizeof d);
    printf("name: "); if(!fgets(line,sizeof line,stdin)) return 1;
    if(strchr(line,'\n')==NULL){ int c; while((c=getchar())!='\n'&&c!=EOF); fprintf(stderr,"name too long, truncated\n"); }
    line[strcspn(line,"\n")]='\0'; strncpy(d.name,line,sizeof d.name-1);
    printf("registered: \"%s\" (%zu chars kept)\n",d.name,strlen(d.name)); return 0; }

  return usage();
}
