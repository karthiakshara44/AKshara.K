#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(void){
  char *line=NULL; size_t cap=0; ssize_t len; long lines=0;
  struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a);
  while((len=getline(&line,&cap,stdin))!=-1){ lines++; 
     printf("line %ld: length %zd, buffer capacity now %zu\n",lines,len,cap); }
  clock_gettime(CLOCK_MONOTONIC,&b);
  printf("elapsed %.3f ms\n",(b.tv_sec-a.tv_sec)*1e3+(b.tv_nsec-a.tv_nsec)/1e6);
  free(line);                 /* caller owns and frees the buffer, once, after the loop */
  return 0; }
