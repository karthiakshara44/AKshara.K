#include <stdio.h>
#include <string.h>
/* usage: b2_input scanf | fgets   (reads a donor name into a 16-byte array) */
int main(int argc, char **argv)
{
    char name[16];
    char after[16] = "SENTINEL";
    if (argc < 2) { fprintf(stderr, "usage: %s scanf|fgets\n", argv[0]); return 2; }
    if (strcmp(argv[1], "scanf") == 0) {
        scanf("%s", name);                       /* UNSAFE: no width limit */
    } else {
        if (fgets(name, sizeof name, stdin) == NULL) return 1;   /* SAFE: at most 15 chars + NUL */
        name[strcspn(name, "\n")] = '\0';
    }
    printf("name  = \"%s\" (strlen %zu)\n", name, strlen(name));
    printf("after = \"%s\"\n", after);
    return 0;
}
