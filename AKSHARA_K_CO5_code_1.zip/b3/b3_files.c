#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>

typedef struct { int id; char name[32]; char group[4]; int age; char phone[16]; int last; } Donor;
static const char *G[8]={"A+","A-","B+","B-","AB+","AB-","O+","O-"};
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e3+t.tv_nsec/1e6; }
static long fsize(const char*p){ struct stat st; stat(p,&st); return st.st_size; }
static int cmpd(const void*a,const void*b){ double x=*(double*)a,y=*(double*)b; return (x>y)-(x<y); }
static double med(double*v,int n){ qsort(v,n,sizeof(double),cmpd); return v[n/2]; }

static void make(Donor*d,int i){ memset(d,0,sizeof *d); d->id=100000+i; snprintf(d->name,sizeof d->name,"Donor_%d",i);
  strcpy(d->group,G[i%8]); d->age=18+i%48; snprintf(d->phone,sizeof d->phone,"9%09d",(i*7919)%1000000000);
  d->last=(2025+i%2)*10000+(1+i%12)*100+(1+i%28); }

static void write_text(const char*p,Donor*d,int n){ FILE*f=fopen(p,"w"); for(int i=0;i<n;i++)
  fprintf(f,"%d|%s|%s|%d|%s|%d\n",d[i].id,d[i].name,d[i].group,d[i].age,d[i].phone,d[i].last); fclose(f); }
static int read_text(const char*p,Donor*d){ FILE*f=fopen(p,"r"); char line[256]; int n=0;
  while(fgets(line,sizeof line,f)){ Donor*x=&d[n]; memset(x,0,sizeof *x);
    if(sscanf(line,"%d|%31[^|]|%3[^|]|%d|%15[^|]|%d",&x->id,x->name,x->group,&x->age,x->phone,&x->last)==6) n++; }
  fclose(f); return n; }
static void write_bin(const char*p,Donor*d,int n){ FILE*f=fopen(p,"wb"); for(int i=0;i<n;i++) fwrite(&d[i],sizeof(Donor),1,f); fclose(f); }
static int read_bin(const char*p,Donor*d){ FILE*f=fopen(p,"rb"); int n=0; while(fread(&d[n],sizeof(Donor),1,f)==1) n++; fclose(f); return n; }
static int same(Donor*a,Donor*b,int n){ for(int i=0;i<n;i++){ if(a[i].id!=b[i].id||strcmp(a[i].name,b[i].name)||strcmp(a[i].group,b[i].group)||
  a[i].age!=b[i].age||strcmp(a[i].phone,b[i].phone)||a[i].last!=b[i].last) return 0; } return 1; }

/* rewrite whole text file with record #k changed (age+1) */
static void text_update(const char*p,int k){
  FILE*in=fopen(p,"r"); FILE*out=fopen("upd.tmp","w"); char line[256]; int i=0;
  while(fgets(line,sizeof line,in)){ if(i==k){ Donor x; memset(&x,0,sizeof x);
      sscanf(line,"%d|%31[^|]|%3[^|]|%d|%15[^|]|%d",&x.id,x.name,x.group,&x.age,x.phone,&x.last); x.age++;
      fprintf(out,"%d|%s|%s|%d|%s|%d\n",x.id,x.name,x.group,x.age,x.phone,x.last); } else fputs(line,out); i++; }
  fclose(in); fclose(out); rename("upd.tmp",p); }
static void bin_update(const char*p,int k){
  FILE*f=fopen(p,"r+b"); Donor x; fseek(f,(long)k*(long)sizeof x,SEEK_SET); fread(&x,sizeof x,1,f); x.age++;
  fseek(f,-(long)sizeof x,SEEK_CUR); fwrite(&x,sizeof x,1,f); fclose(f); }

int main(int argc,char**argv){
  int n=atoi(argv[1]); int R=5;
  Donor *src=malloc((size_t)n*sizeof(Donor)), *back=malloc((size_t)n*sizeof(Donor));
  for(int i=0;i<n;i++) make(&src[i],i);
  double tw[5],tr[5],bw[5],br[5],bw1[5];
  for(int r=0;r<R;r++){
    double t=now(); write_text("d.txt",src,n); tw[r]=now()-t;
    t=now(); int m=read_text("d.txt",back); tr[r]=now()-t; if(m!=n) printf("TEXT COUNT MISMATCH\n");
    t=now(); write_bin("d.bin",src,n); bw[r]=now()-t;
    t=now(); m=read_bin("d.bin",back); br[r]=now()-t; if(m!=n) printf("BIN COUNT MISMATCH\n");
    t=now(); { FILE*f=fopen("d1.bin","wb"); fwrite(src,sizeof(Donor),n,f); fclose(f);} bw1[r]=now()-t;
  }
  int ok_t,ok_b; read_text("d.txt",back); ok_t=same(src,back,n); read_bin("d.bin",back); ok_b=same(src,back,n);
  printf("N=%d | text: %ld B, write %.2f ms, read %.2f ms | binary: %ld B (record %zu B), write %.2f ms, read %.2f ms | bin one-fwrite %.2f ms | roundtrip text=%s bin=%s\n",
    n,fsize("d.txt"),med(tw,R),med(tr,R),fsize("d.bin"),sizeof(Donor),med(bw,R),med(br,R),med(bw1,R),ok_t?"IDENTICAL":"DIFFERENT",ok_b?"IDENTICAL":"DIFFERENT");
  if(n>=50000){ int k=49999; double tb[2000],tt[5];
    for(int r=0;r<2000;r++){ double t=now(); bin_update("d.bin",k); tb[r]=now()-t; }
    for(int r=0;r<5;r++){ double t=now(); text_update("d.txt",k); tt[r]=now()-t; }
    printf("   update 50,000th record: binary fseek median %.4f ms, text rewrite median %.2f ms\n",med(tb,2000),med(tt,5)); }
  free(src); free(back); return 0; }
