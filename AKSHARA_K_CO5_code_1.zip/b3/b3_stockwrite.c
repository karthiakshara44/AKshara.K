#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef struct { int group_code; int units; } Stock;
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e3+t.tv_nsec/1e6; }
int main(int argc,char**argv){ int n=atoi(argv[1]); Stock*s=malloc(n*sizeof *s); for(int i=0;i<n;i++){s[i].group_code=i%8;s[i].units=i%50;}
  double best1=1e9,best2=1e9;
  for(int r=0;r<5;r++){ double t=now(); FILE*f=fopen("s1.bin","wb"); for(int i=0;i<n;i++) fwrite(&s[i],sizeof(Stock),1,f); fclose(f); double a=now()-t; if(a<best1)best1=a;
    t=now(); f=fopen("s2.bin","wb"); fwrite(s,sizeof(Stock),n,f); fclose(f); a=now()-t; if(a<best2)best2=a; }
  printf("n=%d: per-record fwrite %d calls %.2f ms | one fwrite 1 call %.2f ms | array memory %zu bytes\n",n,n,best1,best2,n*sizeof(Stock));
  free(s); return 0; }
