#include <stdio.h>
#include <stdlib.h>
int main(int argc,char**argv){ int n=atoi(argv[1]); const char*G[8]={"A+","A-","B+","B-","AB+","AB-","O+","O-"};
  FILE*f=fopen(argv[2],"w"); unsigned s=12345;
  for(int i=0;i<n;i++){ s=s*1103515245u+12345u; int r=(s>>8)&0xffff;
    fprintf(f,"%d|Donor_%d|%s|%d|9%09d|%d%02d%02d\n",100000+i,i,G[i%8],18+r%48,(int)((i*7919u)%1000000000u),2026-(r%3==0),1+(r/7)%12,1+(r/3)%28); }
  fclose(f); return 0; }
