/* Nightly report: donors who will be eligible within the next 7 days.
   mode "list"   = load all donors into a growable array, then scan it
   mode "stream" = read the file line by line, keep nothing                */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>

typedef struct { int id; char name[32]; char group[4]; int age; char phone[16]; int last; } Donor;
typedef struct { Donor *data; int size, capacity; } DonorList;

static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e3+t.tv_nsec/1e6; }
static long days_from_ymd(int ymd){ int y=ymd/10000,m=ymd/100%100,d=ymd%100; y-=m<=2; long era=(y>=0?y:y-399)/400; long yoe=y-era*400;
  long doy=(153*(m+(m>2?-3:9))+2)/5+d-1; long doe=yoe*365+yoe/4-yoe/100+doy; return era*146097+doe-719468; }
static int eligible_by(const Donor*d,long cutoff_day){ return d->age>=18&&d->age<=65&&days_from_ymd(d->last)+90<=cutoff_day; }
static int parse(const char*line,Donor*d){ memset(d,0,sizeof *d);
  return sscanf(line,"%d|%31[^|]|%3[^|]|%d|%15[^|]|%d",&d->id,d->name,d->group,&d->age,d->phone,&d->last)==6; }

int add_donor(DonorList*l,const Donor*d){
  if(l->size==l->capacity){ int nc=l->capacity==0?2:l->capacity*2; Donor*p=realloc(l->data,(size_t)nc*sizeof *p);
    if(p==NULL) return 0; l->data=p; l->capacity=nc; }
  l->data[l->size++]=*d; return 1; }

int main(int argc,char**argv){
  if(argc<3){ fprintf(stderr,"usage: %s list|stream donors.txt [report.txt]\n",argv[0]); return 2; }
  const char*mode=argv[1]; long today=days_from_ymd(20261119), cutoff=today+7;
  FILE*in=fopen(argv[2],"r"); if(!in){ perror(argv[2]); return 1; }
  FILE*out=fopen(argc>3?argv[3]:"/dev/null","w"); if(!out){ perror("report"); fclose(in); return 1; }
  char line[256]; Donor d; long hits=0; double t0=now();
  if(strcmp(mode,"list")==0){
    DonorList l={NULL,0,0};
    while(fgets(line,sizeof line,in)) if(parse(line,&d)&&!add_donor(&l,&d)){ fprintf(stderr,"out of memory after %d donors\n",l.size); free(l.data); fclose(in); fclose(out); return 1; }
    double t1=now();
    for(int i=0;i<l.size;i++) if(eligible_by(&l.data[i],cutoff)){ hits++; fprintf(out,"%d %s %s\n",l.data[i].id,l.data[i].name,l.data[i].group); }
    double t2=now();
    struct rusage ru; getrusage(RUSAGE_SELF,&ru);
    printf("list  : %d donors, %ld eligible | load %.0f ms, scan %.0f ms, total %.0f ms | capacity %d x %zu B = %.1f MB | peak RSS %.1f MB\n",
      l.size,hits,t1-t0,t2-t1,t2-t0,l.capacity,sizeof(Donor),(double)l.capacity*sizeof(Donor)/1e6,ru.ru_maxrss/1024.0);
    free(l.data);
  } else {
    long n=0; while(fgets(line,sizeof line,in)) if(parse(line,&d)){ n++; if(eligible_by(&d,cutoff)){ hits++; fprintf(out,"%d %s %s\n",d.id,d.name,d.group); } }
    double t1=now(); struct rusage ru; getrusage(RUSAGE_SELF,&ru);
    printf("stream: %ld donors, %ld eligible | total %.0f ms | working memory 1 record (%zu B) | peak RSS %.1f MB\n",n,hits,t1-t0,sizeof(Donor),ru.ru_maxrss/1024.0);
  }
  fclose(in); fclose(out); return 0; }
