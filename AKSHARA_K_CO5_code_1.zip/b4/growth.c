#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static double now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec*1e3+t.tv_nsec/1e6; }
int main(void){ int ns[]={1000,10000,100000,1000000};
 for(int k=0;k<4;k++){ int n=ns[k];
  for(int mode=0;mode<2;mode++){ int *a=NULL; long cap=0,size=0,copied=0,reallocs=0; double t=now();
    for(int i=0;i<n;i++){ if(size==cap){ long nc= mode? cap+10 : (cap==0?2:cap*2); copied+=size; reallocs++; a=realloc(a,nc*sizeof *a); cap=nc; } a[size++]=i; }
    printf("n=%d %-8s reallocs=%ld elements_copied(worst case)=%ld max_unused=%ld time=%.2f ms\n",n,mode?"fixed+10":"doubling",reallocs,copied,cap-size,now()-t); free(a);} }
 return 0; }
